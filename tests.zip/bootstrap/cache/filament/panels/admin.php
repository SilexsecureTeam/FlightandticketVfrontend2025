<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.airline-resource.pages.manage-airlines' => 'App\\Filament\\Resources\\AirlineResource\\Pages\\ManageAirlines',
    'app.filament.resources.flight.flight-order-resource.pages.create-flight-order' => 'App\\Filament\\Resources\\Flight\\FlightOrderResource\\Pages\\CreateFlightOrder',
    'app.filament.resources.flight.flight-order-resource.pages.edit-flight-order' => 'App\\Filament\\Resources\\Flight\\FlightOrderResource\\Pages\\EditFlightOrder',
    'app.filament.resources.flight.flight-order-resource.pages.list-flight-orders' => 'App\\Filament\\Resources\\Flight\\FlightOrderResource\\Pages\\ListFlightOrders',
    'app.filament.resources.flight.flight-order-resource.pages.view-flight-order' => 'App\\Filament\\Resources\\Flight\\FlightOrderResource\\Pages\\ViewFlightOrder',
    'app.filament.resources.payment.payment-resource.pages.create-payment' => 'App\\Filament\\Resources\\Payment\\PaymentResource\\Pages\\CreatePayment',
    'app.filament.resources.payment.payment-resource.pages.edit-payment' => 'App\\Filament\\Resources\\Payment\\PaymentResource\\Pages\\EditPayment',
    'app.filament.resources.payment.payment-resource.pages.list-payments' => 'App\\Filament\\Resources\\Payment\\PaymentResource\\Pages\\ListPayments',
    'app.filament.resources.payment.payment-resource.pages.view-payment' => 'App\\Filament\\Resources\\Payment\\PaymentResource\\Pages\\ViewPayment',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'app.filament.widgets.dashboard-overview' => 'App\\Filament\\Widgets\\DashboardOverview',
    'app.filament.widgets.stats-overview-widget' => 'App\\Filament\\Widgets\\StatsOverviewWidget',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\Users\\user\\p\\silex\\mymore\\mymore-w\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\Users\\user\\p\\silex\\mymore\\mymore-w\\app\\Filament\\Resources\\AirlineResource.php' => 'App\\Filament\\Resources\\AirlineResource',
    'C:\\Users\\user\\p\\silex\\mymore\\mymore-w\\app\\Filament\\Resources\\Flight\\FlightOrderResource.php' => 'App\\Filament\\Resources\\Flight\\FlightOrderResource',
    'C:\\Users\\user\\p\\silex\\mymore\\mymore-w\\app\\Filament\\Resources\\Payment\\PaymentResource.php' => 'App\\Filament\\Resources\\Payment\\PaymentResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\Users\\user\\p\\silex\\mymore\\mymore-w\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'C:\\Users\\user\\p\\silex\\mymore\\mymore-w\\app\\Filament\\Widgets\\DashboardOverview.php' => 'App\\Filament\\Widgets\\DashboardOverview',
    0 => 'Filament\\Widgets\\AccountWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\Users\\user\\p\\silex\\mymore\\mymore-w\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);