<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label' => 'Date',
    'name' => 'date',
    'placeholder' => 'Select a date',
    'initialDate' => null,
    'minDate' => null,
    'type' => 'departure',
    'wire' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label' => 'Date',
    'name' => 'date',
    'placeholder' => 'Select a date',
    'initialDate' => null,
    'minDate' => null,
    'type' => 'departure',
    'wire' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div x-data="datePicker({
    label: '<?php echo e($label); ?>',
    initialDate: '<?php echo e($initialDate); ?>',
    minDate: '<?php echo e($minDate); ?>',
    type: '<?php echo e($type); ?>',
    name: '<?php echo e($name); ?>',
    wire: '<?php echo e($wire); ?>'
})" class="relative w-full">
    <div class="relative flex rounded-lg gap-3 p-3 mb-4">
        <svg class="lg:size-16 size-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
        </svg>
        <div>
            <div class="text-white text-xs lg:text-base" x-text="label"></div>
            <input type="text" :name="name" placeholder="<?php echo e($placeholder); ?>"
                @click="showPicker = !showPicker" readonly x-model="dateFormatted"
                class="w-full placeholder:text-xs bg-transparent text-white text-xs lg:text-xl focus:outline-none cursor-pointer">
            <input type="hidden" :name="`${name}_hidden`" x-model="dateValue">
        </div>
    </div>

    <!-- Date Picker -->
    <div x-show="showPicker" @click.away="showPicker = false"
        class="absolute top-0 left-0 mt-2 bg-white rounded-lg shadow-lg z-50 w-full">
        <div class="px-4 py-2 bg-primary text-white rounded-t-lg">
            <h2 x-text="`Select ${label}`" class="text-xs font-semibold"></h2>
        </div>
        <div class="p-4">
            <!-- Month Navigation -->
            <div class="flex justify-between items-center mb-4">
                <button @click.prevent="prevMonth()" type="button"
                    class="hover:text-gray-800 bg-primary text-white px-2 py-1 rounded-md">&lt;</button>
                <div x-text="months[currentMonth.getMonth()] + ' ' + currentMonth.getFullYear()"
                    class="font-semibold text-lg text-gray-700"></div>
                <button @click.prevent="nextMonth()" type="button"
                    class="text-white hover:text-gray-800 bg-primary px-2 py-1 rounded-md">&gt;</button>
            </div>
            <div class="grid grid-cols-7 text-center text-sm font-semibold text-gray-600 mb-2">
                <template x-for="day in days" :key="day">
                    <div x-text="day" class="py-1"></div>
                </template>
            </div>
            <div class="grid grid-cols-7 gap-1 text-xs">
                <template x-for="(date, index) in calendarDates" :key="index">
                    <div>
                        <div @click="selectDate(date)"
                            :class="{
                                'text-gray-300': !date || isPastDate(date),
                                'text-gray-800 hover:bg-blue-100 cursor-pointer': date && !isPastDate(date),
                                'bg-primary text-white': date && isSelected(date),
                                'border border-primary animate-bounce text-primary': date && isToday(date),
                                'rounded-full flex items-center justify-center h-8 w-8': true
                            }"
                            x-text="date ? date.getDate() : ''">
                        </div>
                    </div>
                </template>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('alpine:init', () => {
        Alpine.data('datePicker', ({
            label,
            initialDate,
            minDate,
            type,
            name,
            wire
        }) => ({
            showPicker: false,
            dateFormatted: '',
            dateValue: '',
            selectedDate: null,
            currentMonth: new Date(),
            calendarDates: [],
            days: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
            months: [
                'January', 'February', 'March', 'April', 'May', 'June',
                'July', 'August', 'September', 'October', 'November', 'December'
            ],
            label: label || 'Date',
            name: name || 'date',
            type: type || 'departure',
            minDate: minDate ? new Date(minDate) : null,
            wire: wire || null,

            init() {
                if (initialDate) {
                    this.selectedDate = new Date(initialDate);
                    this.dateFormatted = this.formatDate(this.selectedDate);
                    this.dateValue = this.formatDateValue(this.selectedDate);
                }

                this.generateCalendar();

                this.$watch('currentMonth', () => {
                    this.generateCalendar();
                });
            },

            formatDate(date) {
                const day = this.days[date.getDay()];
                const month = this.months[date.getMonth()].slice(0, 3);
                return `${day}, ${date.getDate()} ${month} ${date.getFullYear()}`;
            },

            formatDateValue(date) {
                // Format as YYYY-MM-DD for form submission
                const year = date.getFullYear();
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const day = String(date.getDate()).padStart(2, '0');
                return `${year}-${month}-${day}`;
            },

            generateCalendar() {
                const year = this.currentMonth.getFullYear();
                const month = this.currentMonth.getMonth();
                const firstDay = new Date(year, month, 1).getDay(); // First day of the month
                const daysInMonth = new Date(year, month + 1, 0).getDate(); // Total days in month

                const dates = [];

                // Add empty slots for days before the first day of month
                for (let i = 0; i < firstDay; i++) {
                    dates.push(null);
                }

                // Add all days in the month
                for (let day = 1; day <= daysInMonth; day++) {
                    dates.push(new Date(year, month, day));
                }

                this.calendarDates = dates;
            },

            isToday(date) {
                if (!date) return false;
                const today = new Date();
                return (
                    date.getDate() === today.getDate() &&
                    date.getMonth() === today.getMonth() &&
                    date.getFullYear() === today.getFullYear()
                );
            },

            isSelected(date) {
                if (!date || !this.selectedDate) return false;
                return (
                    date.getDate() === this.selectedDate.getDate() &&
                    date.getMonth() === this.selectedDate.getMonth() &&
                    date.getFullYear() === this.selectedDate.getFullYear()
                );
            },

            isPastDate(date) {
                if (!date) return false;
                const today = new Date();
                today.setHours(0, 0, 0, 0); // Reset time to midnight

                if (this.minDate && this.type === 'return') {
                    return date < today || date < this.minDate;
                }

                return date < today;
            },

            selectDate(date) {
                if (!date || this.isPastDate(date)) return;

                this.selectedDate = date;
                this.dateFormatted = this.formatDate(date);
                this.dateValue = this.formatDateValue(date);
                this.showPicker = false;

                // If Livewire integration is enabled
                if (this.wire) {
                    // Format date for Livewire as MM/DD/YYYY
                    const formattedForLivewire = date.toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: '2-digit',
                        day: '2-digit'
                    });

                    // Call Livewire method
                    this.$wire.call('dateSelected', formattedForLivewire, this.type);
                }
            },

            prevMonth() {
                const newDate = new Date(this.currentMonth);
                newDate.setMonth(newDate.getMonth() - 1);
                this.currentMonth = newDate;
            },

            nextMonth() {
                const newDate = new Date(this.currentMonth);
                newDate.setMonth(newDate.getMonth() + 1);
                this.currentMonth = newDate;
            }
        }));
    });
</script>
<?php /**PATH C:\Users\user\p\silex\mymore\mymore-w\resources\views/components/datapicker.blade.php ENDPATH**/ ?>