<div x-data="{

    showFilters: false
}">
    <!-- Mobile Filter Modal -->
    <div x-cloak x-show="showFilters" class="fixed inset-0 bg-black bg-opacity-50 z-50 md:hidden"
        x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100" x-transition:leave="transition ease-in duration-300"
        x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0">
        <div class="bg-white h-full w-full overflow-y-auto" x-transition:enter="transition ease-out duration-300"
            x-transition:enter-start="translate-y-full" x-transition:enter-end="translate-y-0"
            x-transition:leave="transition ease-in duration-300" x-transition:leave-start="translate-y-0"
            x-transition:leave-end="translate-y-full">
            <div class="p-6 space-y-6">
                <!-- Filter content (copy from sidebar) -->
                <div class="flex justify-between items-center">
                    <h2 class="text-lg font-semibold">Filters</h2>
                    <button @click="showFilters = false" class="text-gray-500">&times;</button>
                </div>



            </div>
        </div>
    </div>

    <div x-data="{
        currentStep: 'select-flight',
        steps: [
            { id: 'search-flight', label: 'Search Flight' },
            { id: 'select-flight', label: 'Select Flight' },
            { id: 'additional-info', label: 'Additional Info' },
            { id: 'payment', label: 'Payment' }
        ]
    }" class="bg-black sticky top-[14%] w-full z-[99]">
        <div class="px-5 sm:px-5 md:px-16 py-4">
            <div class="flex items-center justify-between space-x-4 mb-2">
                <!-- Title -->
                <div class="text-lg font-bold text-white shrink-0">Flight Details</div>

                <!-- Stepper container -->
                <div class="flex-1  hidden md:inline  relative min-h-[64px] max-w-3xl mx-auto">
                    <div class="absolute inset-0 flex items-center justify-between px-4">
                        <!-- Progress bar background -->
                        <div class="absolute h-1 bg-gray-700 w-full"></div>

                        <!-- Active progress bar -->
                        <div class="absolute h-1 bg-primary transition-all duration-300"
                            :style="'width: ' + (steps.findIndex(step => step.id === currentStep) / (steps.length - 1) * 100) +
                            '%'">
                        </div>

                        <!-- Steps container -->
                        <div class="relative flex justify-between w-full">
                            <template x-for="(step, index) in steps" :key="step.id">
                                <div class="relative flex flex-col items-center w-24">
                                    <!-- Circle -->
                                    <div class="w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 z-10"
                                        :class="{
                                            'bg-primary text-white': currentStep === step.id,
                                            'bg-white text-black': steps.findIndex(s => s.id === currentStep) > index,
                                            'bg-white text-gray-400': steps.findIndex(s => s.id === currentStep) < index
                                        }">
                                        <span x-text="index + 1" class="text-sm font-medium"></span>
                                    </div>
                                    <!-- Label -->
                                    <div class="absolute -bottom-6 text-xs text-center w-full transition-all duration-300"
                                        :class="{
                                            'text-primary': currentStep === step.id,
                                            'text-white': steps.findIndex(s => s.id === currentStep) > index,
                                            'text-white': steps.findIndex(s => s.id === currentStep) < index
                                        }">
                                        <span x-text="step.label" class="inline-block"></span>
                                    </div>
                                </div>
                            </template>
                        </div>
                    </div>
                </div>

                <div x-data="{ isEditOpen: false }" class="">
                    <div class="flex items-center justify-end">

                        <button @click="isEditOpen = !isEditOpen"
                            class="p-3 items-end justify-end bg-primary text-white rounded-2xl">Edit</button>
                        <div x-show="isEditOpen" x-cloak class=" z-[99999] absolute top-20   ">
                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.search');

$__html = app('livewire')->mount($__name, $__params, 'lw-2085732413-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                        </div>
                    </div>

                </div>

                
            </div>
        </div>
    </div>
    <!-- Main Container -->
    <div class=" relative w-full  flex flex-col md:flex-row min-h-screen">
        <!-- Sidebar (hidden on mobile) -->
        <div class="hidden md:block w-[20%]  overflow-y-auto bg-white text-black h-screen p-1 border flex-shrink-0">
            <div class="p-6 space-y-6">
                <!-- Filter content (unchanged) -->
                <h2 class="text-lg font-semibold">Filters</h2>
                <?php if(isset($searchResults['flightOffers']) &&
                        is_array($searchResults['flightOffers']) &&
                        count($searchResults['flightOffers'])): ?>
                    <?php
                        // Convert flight offers to a collection
                        $flightOffersCollection = collect($searchResults['flightOffers']);

                        // Extract unique stop options from flight data
                        $stopOptions = $flightOffersCollection
                            ->flatMap(function ($flight) {
                                return collect($flight['itineraries'] ?? []) // Handle missing itineraries
                                    ->map(function ($itinerary) {
                                        // Calculate total stops for the itinerary
                                        return count($itinerary['segments'] ?? []) - 1;
                                    })
                                    ->unique();
                            })
                            ->unique()
                            ->values();

                        // Convert stop numbers to descriptive strings
                        $stopLabels = [
                            0 => 'Non-stop',
                            1 => '1 Stop',
                            2 => '2 Stops',
                            // Add more as needed
                        ];

                        // Map stop options to their labels
                        $stopOptionsWithLabels = $stopOptions->map(function ($stops) use ($stopLabels) {
                            return ['value' => $stops, 'label' => $stopLabels[$stops] ?? "$stops Stops"];
                        });

                        // Extract unique validating airline codes from flight offers
                        $uniqueAirlines = $flightOffersCollection
                            ->pluck('validatingAirlineCodes')
                            ->flatten()
                            ->unique()
                            ->values();

                        $airlinesWithNames = $uniqueAirlines->map(function ($code) use ($searchResults) {
                            $name = $searchResults['dictionaries']['carriers'][$code] ?? 'Unknown';
                            return ['code' => $code, 'name' => $name];
                        });
                    ?>

                    <!-- Filter by Airlines -->
                    <!-- Filter by Airlines -->
                    <div class="mb-6">
                        <h3 class="text-base font-medium mb-4">Filter by Airlines</h3>
                        <?php if(isset($airlinesWithNames) && count($airlinesWithNames)): ?>
                            <ul class="space-y-2">
                                <?php $__currentLoopData = $airlinesWithNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <label class="flex items-center gap-2 space-x-2 text-xs">
                                            <input type="checkbox" value="<?php echo e($airline['code']); ?>"
                                                onclick="toggleAirline(this)">

                                            <?php echo e($airline['name']); ?>

                                        </label>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <p>No airlines found.</p>
                        <?php endif; ?>
                    </div>

                    <!-- Filter by Number of Stops -->
                    <div class="mb-6">
                        <h3 class="text-base font-medium mb-4">Filter by Number of Stops</h3>
                        <ul>
                            <?php $__currentLoopData = $stopOptionsWithLabels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <label>
                                        <input type="checkbox" value="<?php echo e($option['value']); ?>"
                                            onclick="toggleStopFilter(this)">
                                        <?php echo e($option['label']); ?>

                                    </label>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php else: ?>
                    <p>No flights found.</p>
                <?php endif; ?>



                <!-- Price -->
                




            </div>
        </div>

        <!-- Main Content -->
        <div class="flex-1 w-full  justify-center items-center">
            <!-- Header -->



            <!-- Mobile Filter Button -->
            <div class="hidden p-4">
                <button @click="showFilters = !showFilters"
                    class="w-full bg-blue-900 text-white rounded-lg py-3 text-sm font-medium">
                    Filters
                </button>
            </div>



            <!-- Property Grid -->
            <!-- Property Grid -->
            <div class="md:p-3 p-2  text-black">

                <!-- Sort by Cheapest and Fastest -->

                <div class="mb-6">
                    <h3 class="text-base font-medium mb-4">Sort By</h3>
                    <div class="flex space-x-4">
                        <!-- Cheapest Button -->
                        <!-- Cheapest Button -->
                        <button onclick="sortFlights('cheapest')" id="cheapest-btn"
                            class="px-4 py-2  rounded-md bg-primary text-white">
                            Cheapest
                        </button>

                        <!-- Fastest Button -->
                        <button onclick="sortFlights('fastest')" id="fastest-btn"
                            class="px-4 py-2 rounded-md  text-black">
                            Fastest
                        </button>
                    </div>
                </div>
                <div class=" space-y-4" id="flight-list">
                    <?php if(isset($searchResults['flightOffers']) && count($searchResults['flightOffers'])): ?>
                        <div id="flight-offers-container">
                            <?php $__currentLoopData = $searchResults['flightOffers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    // Calculate total price
                                    $flight['totalPrice'] = floatval($flight['price']['grandTotal']);

                                    // Calculate total duration
                                    $totalDurationInSeconds = 0;
                                    foreach ($flight['itineraries'] as $itinerary) {
                                        foreach ($itinerary['segments'] as $segment) {
                                            $durationParts = explode('PT', $segment['duration']);
                                            if (isset($durationParts[1])) {
                                                $timeParts = explode('H', $durationParts[1]);
                                                $hours = isset($timeParts[0]) ? intval($timeParts[0]) : 0;
                                                $minutes = isset($timeParts[1])
                                                    ? intval(str_replace('M', '', $timeParts[1]))
                                                    : 0;
                                                $totalDurationInSeconds += $hours * 3600 + $minutes * 60;
                                            }
                                        }
                                    }
                                    $flight['totalDuration'] = $totalDurationInSeconds; // Duration in seconds
                                ?>
                                <div data-airline="<?php echo e($flight['validatingAirlineCodes'][0]); ?>"
                                    data-total-stops="<?php echo e($flight['itineraries'][0]['segments'] ? count($flight['itineraries'][0]['segments']) - 1 : 0); ?>"
                                    data-price="<?php echo e($flight['totalPrice']); ?>"
                                    data-duration="<?php echo e($flight['totalDuration']); ?>"
                                    style="<?php echo e($index >= 10 ? 'display: none;' : ''); ?>"
                                    class="flight-offer bg-white rounded-xl shadow-xl border-b border-dotted-2 mb-6 overflow-hidden  border-primary">
                                    <div x-data="{ isOpen: false }">
                                        <div class="flex space-x-4 mb-2 p-3">
                                            <label class="inline-flex items-center">
                                                <input type="checkbox" wire:model="selectedIncludes" value="bags"
                                                    class="form-checkbox">
                                                <span class="ml-2">Include Bags</span>
                                            </label>

                                        </div>


                                        <!-- Main Flight Information -->
                                        <div class="p-6">
                                            <div class="grid grid-cols-12 gap-6">
                                                <!-- Left Section: Flight Route -->
                                                <div class="col-span-12 lg:col-span-7">
                                                    <!-- Flight Type Badge -->
                                                    <div class="mb-4">
                                                        <span
                                                            class="inline-flex items-center px-3 py-1 rounded-full text-sm 
                                                       bg-white text-primary">
                                                            <?php echo e($searchResults['tripType'] !== 'round' ? 'One Way' : 'Round Trip'); ?>

                                                        </span>
                                                    </div>

                                                    <!-- Outbound Flight -->
                                                    <?php $__currentLoopData = $flight['itineraries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $itinerary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="mb-6 last:mb-0">
                                                            <div class="text-sm font-medium text-gray-500 mb-3">
                                                                <?php echo e($index === 0 ? 'Depature' : 'Return'); ?> Flight
                                                            </div>

                                                            <!-- Airline info - Full width on mobile, normal on desktop -->
                                                            <div
                                                                class="flex flex-col md:flex-row items-start md:items-center mb-4 md:mb-0">


                                                                <!-- Flight duration and stops - Mobile only -->
                                                                <div class="w-full md:hidden mb-4">
                                                                    <div class="flex items-center justify-center">
                                                                        <div class="text-sm font-medium">
                                                                            <?php echo e(str_replace(['PT', 'H', 'M'], ['', 'h ', 'm'], $itinerary['duration'])); ?>

                                                                            •
                                                                            <?php if(count($itinerary['segments']) > 1): ?>
                                                                                <span class="text-orange-600">
                                                                                    <?php echo e(count($itinerary['segments']) - 1); ?>

                                                                                    stop(s)
                                                                                </span>
                                                                            <?php else: ?>
                                                                                <span
                                                                                    class="text-green-600">Direct</span>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <!-- Flight details - Stacked on mobile, row on desktop -->
                                                            <div
                                                                class="flex flex-row md:items-center justify-between md:gap-4">

                                                                <div
                                                                    class="flex flex-col items-center justify-center  ">

                                                                    <img src="<?php echo e(!empty($itinerary['segments'][0]['airline']['logo'])
                                                                        ? 'https://main.mymoretravels.com/storage/' . $itinerary['segments'][0]['airline']['logo']
                                                                        : asset('images/default-airline-logo.png')); ?>"
                                                                        alt="<?php echo e($itinerary['segments'][0]['airline']['name']); ?>"
                                                                        class="object-contain w-10 h-10 md:w-12 md:h-12">
                                                                    <div class="text-xs font-medium ">
                                                                        <?php echo e($itinerary['segments'][0]['airline']['name'] ?? 'Unknown Airline'); ?>

                                                                    </div>
                                                                </div>
                                                                <!-- Departure -->
                                                                <div
                                                                    class="flex-shrink-0 flex justify-between md:block mb-2 md:mb-0">

                                                                    <div>
                                                                        <div class="text-xs  font-bold">
                                                                            
                                                                            <?php echo e($itinerary['segments'][0]['departure']['city_country']); ?>

                                                                            (<?php echo e($itinerary['segments'][0]['departure']['iataCode']); ?>)
                                                                        </div>
                                                                        <div class="text-sm text-gray-500">
                                                                            <?php echo e(\Carbon\Carbon::parse($itinerary['segments'][0]['departure']['at'])->format('H:i')); ?>

                                                                        </div>
                                                                        <div class="text-xs text-gray-400">
                                                                            <?php echo e(\Carbon\Carbon::parse($itinerary['segments'][0]['departure']['at'])->format('D, M d')); ?>

                                                                        </div>
                                                                    </div>

                                                                    <!-- Arrow for mobile -->

                                                                </div>

                                                                <div
                                                                    class="md:hidden flex items-center self-center text-gray-400">
                                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                                        class="h-6 w-6" fill="none"
                                                                        viewBox="0 0 24 24" stroke="currentColor">
                                                                        <path stroke-linecap="round"
                                                                            stroke-linejoin="round" stroke-width="2"
                                                                            d="M17 8l4 4m0 0l-4 4m4-4H3" />
                                                                    </svg>
                                                                </div>
                                                                <!-- Flight Path - Desktop only -->
                                                                <div class="hidden md:block flex-1 px-4">
                                                                    <div class="relative">
                                                                        <div class="h-px bg-gray-300 w-full"></div>
                                                                        <div
                                                                            class="absolute inset-0 flex items-center justify-center">
                                                                            <span
                                                                                class="bg-white px-2 text-xs text-gray-500">
                                                                                <?php echo e(str_replace(['PT', 'H', 'M'], ['', 'h ', 'm'], $itinerary['duration'])); ?>

                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                    <!-- Stops Indicator -->
                                                                    <div class="text-center mt-1">
                                                                        <?php if(count($itinerary['segments']) > 1): ?>
                                                                            <span class="text-xs text-orange-600">
                                                                                <?php echo e(count($itinerary['segments']) - 1); ?>

                                                                                stop(s)
                                                                            </span>
                                                                        <?php else: ?>
                                                                            <span
                                                                                class="text-xs text-green-600">Direct</span>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>

                                                                <!-- Arrival -->
                                                                <div class="flex-shrink-0 md:text-right">
                                                                    <?php
                                                                        $lastSegment = end($itinerary['segments']);
                                                                    ?>
                                                                    <div class="text-xs  font-bold">
                                                                        
                                                                        <?php echo e($lastSegment['arrival']['city_country']); ?>

                                                                        (<?php echo e($lastSegment['arrival']['iataCode']); ?>)
                                                                    </div>
                                                                    <div class="text-sm text-gray-500">
                                                                        <?php echo e(\Carbon\Carbon::parse($lastSegment['arrival']['at'])->format('H:i')); ?>

                                                                    </div>
                                                                    <div class="text-xs text-gray-400">
                                                                        <?php echo e(\Carbon\Carbon::parse($lastSegment['arrival']['at'])->format('D, M d')); ?>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>

                                                <!-- Right Section: Price & Booking -->
                                                <div class="col-span-12 lg:col-span-5 flex flex-col justify-between">
                                                    <div class="flex justify-between items-start">
                                                        <!-- Price Information -->
                                                        <div>
                                                            <div class=" text-base md:text-xl font-bold text-gray-900">
                                                                <?php echo e($flight['price']['currency']); ?>

                                                                <?php echo e(number_format((float) $flight['price']['total'] + $markUp, 2)); ?>

                                                            </div>
                                                            <div class="text-xs md:text-sm text-gray-500">
                                                                <?php echo e($flight['travelerPricings'][0]['fareDetailsBySegment'][0]['cabin']); ?>

                                                            </div>
                                                        </div>

                                                        <!-- Flight Details -->
                                                        <div class="text-right">
                                                            <div class="text-sm font-medium text-gray-900">
                                                                <?php echo e($flight['validatingAirlineCodes'][0]); ?>

                                                                <?php echo e($flight['itineraries'][0]['segments'][0]['number']); ?>

                                                            </div>
                                                            <div class="text-sm text-gray-500">
                                                                <?php echo e($flight['numberOfBookableSeats']); ?> seats left
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <!-- Action Buttons -->
                                                    <div class="flex items-center gap-3 justify-between mt-4">
                                                        <button @click="isOpen = !isOpen"
                                                            class="inline-flex items-center md:text-base text-xs px-4 py-2 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50">
                                                            Flight Details
                                                            <svg class="ml-2 h-4 w-4 transition-transform duration-200"
                                                                :class="{ 'transform rotate-180': isOpen }"
                                                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"
                                                                fill="currentColor">
                                                                <path fill-rule="evenodd"
                                                                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                                                                    clip-rule="evenodd" />
                                                            </svg>
                                                        </button>

                                                        <div>
                                                            <button wire:loading.remove
                                                                wire:target='selectFlight(<?php echo e($flight['id']); ?>)'
                                                                class="px-6 py-2 md:text-base text-xs bg-primary text-white rounded-lg hover:bg-red-700"
                                                                wire:click="selectFlight(<?php echo e($flight['id']); ?>)">
                                                                Select Flight
                                                            </button>
                                                            <div wire:loading
                                                                wire:target='selectFlight(<?php echo e($flight['id']); ?>)'>
                                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                                    viewBox="0 0 24 24" aria-hidden="true"
                                                                    class="size-5 fill-neutral-600 motion-safe:animate-spin dark:fill-neutral-300">
                                                                    <path
                                                                        d="M12,1A11,11,0,1,0,23,12,11,11,0,0,0,12,1Zm0,19a8,8,0,1,1,8-8A8,8,0,0,1,12,20Z"
                                                                        opacity=".25" />
                                                                    <path
                                                                        d="M10.14,1.16a11,11,0,0,0-9,8.92A1.59,1.59,0,0,0,2.46,12,1.52,1.52,0,0,0,4.11,10.7a8,8,0,0,1,6.66-6.61A1.42,1.42,0,0,0,12,2.69h0A1.57,1.57,0,0,0,10.14,1.16Z" />
                                                                </svg>
                                                            </div>


                                                        </div>




                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Expanded Flight Details -->
                                        <div x-cloak x-show="isOpen" x-collapse>
                                            <div class="border-t border-gray-200 bg-gray-50">
                                                <div class="p-6 space-y-6">
                                                    <!-- Flight Details Section -->
                                                    <?php $__currentLoopData = $flight['itineraries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $itinerary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="space-y-4">
                                                            <h3 class="font-semibold text-gray-900">
                                                                <?php echo e($index === 0 ? 'Depature' : 'Return'); ?> Flight
                                                                Details
                                                            </h3>

                                                            <?php $__currentLoopData = $itinerary['segments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segIndex => $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div
                                                                    class="bg-white rounded-lg p-4 border border-gray-200">
                                                                    <!-- Segment Header -->
                                                                    <div
                                                                        class="flex items-center justify-start mb-3 md:mb-0 md:mr-4">
                                                                        <img src="<?php echo e(!empty($itinerary['segments'][0]['airline']['logo'])
                                                                            ? 'https://main.mymoretravels.com/storage/' . $itinerary['segments'][0]['airline']['logo']
                                                                            : asset('images/default-airline-logo.png')); ?>"
                                                                            alt="<?php echo e($segment['airline']['name']); ?>"
                                                                            class="object-contain w-16 h-16 md:w-20 md:h-20">
                                                                        <div
                                                                            class="text-base md:text-lg font-medium ml-3">
                                                                            <?php echo e($segment['airline']['name'] ?? 'Unknown Airline'); ?>

                                                                        </div>
                                                                    </div>
                                                                    <div
                                                                        class="flex items-center justify-between mb-4 mt-4">
                                                                        <div class="flex items-center space-x-4">
                                                                            <span class="text-sm  font-medium">
                                                                                Flight <?php echo e($segment['carrierCode']); ?>

                                                                                <?php echo e($segment['number']); ?>

                                                                            </span>
                                                                            <span class="text-xs text-gray-500">
                                                                                Aircraft:
                                                                                <?php echo e($segment['aircraft']['code']); ?>

                                                                            </span>
                                                                        </div>
                                                                        <span class="text-sm text-gray-500">
                                                                            Duration:
                                                                            <?php echo e(str_replace(['PT', 'H', 'M'], ['', 'h ', 'm'], $segment['duration'])); ?>

                                                                        </span>
                                                                    </div>

                                                                    <!-- Flight Details -->
                                                                    <div class="grid grid-cols-2 gap-4">
                                                                        <!-- Departure -->
                                                                        <div>
                                                                            <div class="text-sm text-gray-500">
                                                                                Departure</div>
                                                                            
                                                                            <div
                                                                                class="font-medium text-xs md:text-base">
                                                                                <?php echo e($segment['departure']['city_country']); ?>

                                                                                (<?php echo e($segment['departure']['iataCode']); ?>)
                                                                            </div>
                                                                            <div class="text-sm">Terminal
                                                                                <?php echo e($segment['departure']['terminal'] ?? ''); ?>

                                                                            </div>
                                                                            <div class="text-sm text-gray-500">
                                                                                <?php echo e(\Carbon\Carbon::parse($segment['departure']['at'])->format('D, M d, Y H:i')); ?>

                                                                            </div>
                                                                        </div>

                                                                        <!-- Arrival -->
                                                                        <div class="text-right">
                                                                            <div class="text-sm text-gray-500">Arrival
                                                                            </div>
                                                                            <div
                                                                                class="font-medium text-xs md:text-base">
                                                                                <?php echo e($segment['arrival']['city_country']); ?>

                                                                                
                                                                                (<?php echo e($segment['arrival']['iataCode']); ?>)
                                                                            </div>
                                                                            <div class="text-sm">Terminal
                                                                                <?php echo e($segment['arrival']['terminal'] ?? ''); ?>

                                                                            </div>
                                                                            <div class="text-sm text-gray-500">
                                                                                <?php echo e(\Carbon\Carbon::parse($segment['arrival']['at'])->format('D, M d, Y H:i')); ?>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <!-- Layover Calculation -->
                                                                <?php if(isset($itinerary['segments'][$segIndex + 1])): ?>
                                                                    <?php
                                                                        $currentArrival = \Carbon\Carbon::parse(
                                                                            $segment['arrival']['at'],
                                                                        );
                                                                        $nextDeparture = \Carbon\Carbon::parse(
                                                                            $itinerary['segments'][$segIndex + 1][
                                                                                'departure'
                                                                            ]['at'],
                                                                        );
                                                                        $layoverDiff = $currentArrival->diff(
                                                                            $nextDeparture,
                                                                        );
                                                                        $layoverHours = $layoverDiff->h;
                                                                        $layoverMinutes = $layoverDiff->i;
                                                                        $layoverDuration =
                                                                            ($layoverHours > 0
                                                                                ? $layoverHours . 'h '
                                                                                : '') .
                                                                            ($layoverMinutes > 0
                                                                                ? $layoverMinutes . 'm'
                                                                                : '');

                                                                        $isNightLayover =
                                                                            $currentArrival->hour >= 18 ||
                                                                            $nextDeparture->hour <= 6;
                                                                        $totalMinutes =
                                                                            $layoverHours * 60 + $layoverMinutes;

                                                                        if ($layoverHours >= 8) {
                                                                            $layoverType = $isNightLayover
                                                                                ? 'Overnight Stop'
                                                                                : 'Very Long Stopover';
                                                                            $severityClass = 'bg-red-50 border-red-100';
                                                                            $textClass = 'text-red-700';
                                                                        } elseif ($layoverHours >= 6) {
                                                                            $layoverType = $isNightLayover
                                                                                ? 'Night Stopover'
                                                                                : 'Long Stopover';
                                                                            $severityClass =
                                                                                'bg-orange-50 border-orange-100';
                                                                            $textClass = 'text-orange-700';
                                                                        } elseif ($layoverHours >= 4) {
                                                                            $layoverType = $isNightLayover
                                                                                ? 'Evening Break'
                                                                                : 'Extended Break';
                                                                            $severityClass =
                                                                                'bg-blue-50 border-blue-100';
                                                                            $textClass = 'text-blue-700';
                                                                        } elseif ($totalMinutes >= 90) {
                                                                            $layoverType = 'Comfortable Break';
                                                                            $severityClass =
                                                                                'bg-green-50 border-green-100';
                                                                            $textClass = 'text-green-700';
                                                                        } elseif ($totalMinutes >= 45) {
                                                                            $layoverType =
                                                                                '45 Min Break - Move Quickly';
                                                                            $severityClass =
                                                                                'bg-yellow-50 border-yellow-100';
                                                                            $textClass = 'text-yellow-700';
                                                                        } else {
                                                                            $layoverType = 'Rush Transfer - Very Tight';
                                                                            $severityClass = 'bg-red-50 border-red-100';
                                                                            $textClass = 'text-red-700';
                                                                        }

                                                                        // Add a warning message for tight transfers
                                                                        $warningMessage = '';
                                                                        if ($totalMinutes < 90) {
                                                                            $warningMessage =
                                                                                $totalMinutes < 45
                                                                                    ? 'This is an extremely tight transfer. Check with your airline if this is feasible.'
                                                                                    : 'Pack light and be prepared to move quickly between gates.';
                                                                        }
                                                                    ?>


                                                                    <div
                                                                        class="flex items-center gap-3 my-4 px-4 py-3 rounded-lg border <?php echo e($severityClass); ?>">
                                                                        <div class="flex-shrink-0">
                                                                            <?php if($isNightLayover): ?>
                                                                                <svg class="w-5 h-5 <?php echo e($textClass); ?>"
                                                                                    fill="none"
                                                                                    stroke="currentColor"
                                                                                    viewBox="0 0 24 24">
                                                                                    <path stroke-linecap="round"
                                                                                        stroke-linejoin="round"
                                                                                        stroke-width="2"
                                                                                        d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                                                                                </svg>
                                                                            <?php else: ?>
                                                                                <svg class="w-5 h-5 <?php echo e($textClass); ?>"
                                                                                    fill="none"
                                                                                    stroke="currentColor"
                                                                                    viewBox="0 0 24 24">
                                                                                    <path stroke-linecap="round"
                                                                                        stroke-linejoin="round"
                                                                                        stroke-width="2"
                                                                                        d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                                                                                </svg>
                                                                            <?php endif; ?>
                                                                        </div>

                                                                        <div class="flex flex-col">
                                                                            <div class="flex items-center gap-2">
                                                                                <span
                                                                                    class="font-medium <?php echo e($textClass); ?>"><?php echo e($layoverType); ?></span>
                                                                                <span
                                                                                    class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium <?php echo e($severityClass); ?> <?php echo e($textClass); ?>">
                                                                                    <?php echo e($layoverDuration); ?>

                                                                                </span>
                                                                            </div>
                                                                            <div
                                                                                class="flex items-center gap-1 text-sm text-gray-600">
                                                                                <svg class="w-4 h-4" fill="none"
                                                                                    stroke="currentColor"
                                                                                    viewBox="0 0 24 24">
                                                                                    <path stroke-linecap="round"
                                                                                        stroke-linejoin="round"
                                                                                        stroke-width="2"
                                                                                        d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                                                                    <path stroke-linecap="round"
                                                                                        stroke-linejoin="round"
                                                                                        stroke-width="2"
                                                                                        d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                                                                </svg>
                                                                                <span><?php echo e($segment['arrival']['iataCode']); ?></span>
                                                                                <span class="text-xs text-gray-500">
                                                                                    <?php echo e($currentArrival->format('H:i')); ?>

                                                                                    -
                                                                                    <?php echo e($nextDeparture->format('H:i')); ?>

                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                    <!-- Price Breakdown & Additional Info -->
                                                    <div
                                                        class="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-6 border-t border-gray-200">
                                                        <!-- Price Details -->
                                                        <div>
                                                            <h4 class="font-medium text-gray-900 mb-3">Price Breakdown
                                                            </h4>
                                                            <div class="space-y-2">
                                                                <div class="flex justify-between text-sm">
                                                                    <span class="text-gray-500">Base Fare</span>
                                                                    <span><?php echo e($flight['price']['currency']); ?>

                                                                        <?php echo e(number_format((float) $flight['price']['base'], 2)); ?></span>
                                                                </div>
                                                                <?php $__currentLoopData = $flight['price']['fees']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div class="flex justify-between text-sm">
                                                                        <span
                                                                            class="text-gray-500"><?php echo e(ucfirst(strtolower($fee['type']))); ?></span>
                                                                        <span><?php echo e($flight['price']['currency']); ?>

                                                                            <?php echo e(number_format((float) $fee['amount'], 2)); ?></span>
                                                                    </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <div
                                                                    class="flex justify-between font-medium pt-2 border-t border-gray-200">
                                                                    <span>Total Price</span>
                                                                    <span><?php echo e($flight['price']['currency']); ?>

                                                                        <?php echo e(number_format((float) $flight['price']['grandTotal'] + $markUp, 2)); ?></span>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Baggage Information -->
                                                        <div>
                                                            <h4 class="font-medium text-gray-900 mb-3">Baggage
                                                                Allowance</h4>
                                                            <div class="text-sm text-gray-600">
                                                                <?php if($flight['travelerPricings'][0]['fareDetailsBySegment'][0]['includedCheckedBags']['quantity'] ?? 0 > 0): ?>
                                                                    <div class="flex items-center space-x-2">
                                                                        <svg class="w-5 h-5 text-green-500"
                                                                            fill="none" stroke="currentColor"
                                                                            viewBox="0 0 24 24">
                                                                            <path stroke-linecap="round"
                                                                                stroke-linejoin="round"
                                                                                stroke-width="2" d="M5 13l4 4L19 7" />
                                                                        </svg>
                                                                        <span>
                                                                            <?php echo e($flight['travelerPricings'][0]['fareDetailsBySegment'][0]['includedCheckedBags']['quantity']); ?>

                                                                            checked bags included
                                                                        </span>
                                                                    </div>
                                                                <?php else: ?>
                                                                    <div
                                                                        class="flex items-center space-x-2 text-gray-500">
                                                                        <svg class="w-5 h-5" fill="none"
                                                                            stroke="currentColor" viewBox="0 0 24 24">
                                                                            <path stroke-linecap="round"
                                                                                stroke-linejoin="round"
                                                                                stroke-width="2"
                                                                                d="M6 18L18 6M6 6l12 12" />
                                                                        </svg>
                                                                        <span>No checked bags included</span>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                        <!-- Additional Information -->
                                                        <div>
                                                            <h4 class="font-medium text-gray-900 mb-3">Additional
                                                                Information</h4>
                                                            <div class="space-y-2 text-sm text-gray-600">
                                                                <div>
                                                                    <span class="font-medium">Fare Type:</span>
                                                                    <?php echo e(implode(', ', $flight['pricingOptions']['fareType'])); ?>

                                                                </div>
                                                                <div>
                                                                    <span class="font-medium">Last Ticketing
                                                                        Date:</span>
                                                                    <?php echo e(\Carbon\Carbon::parse($flight['lastTicketingDate'])->format('M d, Y')); ?>

                                                                </div>
                                                                <div>
                                                                    <span class="font-medium">Traveler Type:</span>
                                                                    <?php echo e(ucfirst(strtolower($flight['travelerPricings'][0]['travelerType']))); ?>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                </div>

                <!-- Load More Button -->
                <?php if(count($searchResults['flightOffers']) > 10): ?>
                    <button id="load-more-btn" class="block mx-auto px-4 py-2 bg-primary text-white rounded-md mt-4 ">
                        Load More
                    </button>
                <?php endif; ?>
            <?php else: ?>
                <p>No flights found.</p>
                <?php endif; ?>

            </div>
        </div>
    </div>


    <script>
        let selectedAirlines = [];
        let selectedStops = [];
        let sortBy = 'cheapest'; // 'cheapest' or 'fastest'

        document.addEventListener("DOMContentLoaded", function() {
            const flightOffers = document.querySelectorAll('#flight-offers-container .flight-offer');
            const loadMoreButton = document.getElementById('load-more-btn');
            let itemsToShow = 10; // Number of items to show initially

            // Show initial flights
            flightOffers.forEach((flight, index) => {
                if (index >= itemsToShow) {
                    flight.style.display = 'none'; // Hide flights beyond the initial limit
                }
            });

            // Handle Load More button click
            if (loadMoreButton) {
                loadMoreButton.addEventListener('click', function() {
                    itemsToShow += 10; // Increment by 10

                    flightOffers.forEach((flight, index) => {
                        if (index < itemsToShow) {
                            flight.style.display = 'block'; // Show flights up to the new limit
                        }
                    });

                    // Hide the button if all flights are shown
                    if (itemsToShow >= flightOffers.length) {
                        loadMoreButton.style.display = 'none';
                    }
                });
            }
        });

        // Toggle airline filter
        function toggleAirline(checkbox) {
            const airlineCode = checkbox.value;

            if (checkbox.checked) {
                selectedAirlines.push(airlineCode);
            } else {
                selectedAirlines = selectedAirlines.filter(code => code !== airlineCode);
            }

            filterFlights();
        }

        // Toggle stop filter
        function toggleStopFilter(checkbox) {
            const stopValue = parseInt(checkbox.value);

            if (checkbox.checked) {
                selectedStops.push(stopValue);
            } else {
                selectedStops = selectedStops.filter(stop => stop !== stopValue);
            }

            filterFlights();
        }

        // Sort flights by cheapest or fastest
        function sortFlights(option) {
            sortBy = option;
            updateButtonClasses();
            filterFlights();
        }

        function updateButtonClasses() {
            const cheapestBtn = document.getElementById('cheapest-btn');
            const fastestBtn = document.getElementById('fastest-btn');

            // Reset both buttons to default state
            cheapestBtn.classList.remove('bg-primary', 'text-white');
            cheapestBtn.classList.add('text-black');

            fastestBtn.classList.remove('bg-primary', 'text-white');
            fastestBtn.classList.add('text-black');

            // Apply active state to the selected button
            if (sortBy === 'cheapest') {
                cheapestBtn.classList.add('bg-primary', 'text-white');
                cheapestBtn.classList.remove('text-black');
            } else if (sortBy === 'fastest') {
                fastestBtn.classList.add('bg-primary', 'text-white');
                fastestBtn.classList.remove('text-black');
            }
        }
        // Filter and sort flights
        function filterFlights() {
            const flightList = document.getElementById('flight-list');
            const flights = Array.from(flightList.getElementsByClassName('flight-offer'));

            // Apply filters
            flights.forEach(flight => {
                let hasMatchingAirline = false;
                let hasMatchingStop = false;

                // Check airline filter
                const validatingAirlineCode = flight.getAttribute('data-airline');
                if (selectedAirlines.length === 0 || selectedAirlines.includes(validatingAirlineCode)) {
                    hasMatchingAirline = true;
                }

                // Check stop filter
                const totalStops = parseInt(flight.getAttribute('data-total-stops'));
                if (selectedStops.length === 0 || selectedStops.includes(totalStops)) {
                    hasMatchingStop = true;
                }

                // Show/hide flight based on filters
                flight.style.display = hasMatchingAirline && hasMatchingStop ? 'block' : 'none';
            });

            // Apply sorting
            if (sortBy === 'cheapest') {
                flights.sort((a, b) => parseFloat(a.getAttribute('data-price')) - parseFloat(b.getAttribute('data-price')));
            } else if (sortBy === 'fastest') {
                flights.sort((a, b) => parseFloat(a.getAttribute('data-duration')) - parseFloat(b.getAttribute(
                    'data-duration')));
            }

            // Re-append sorted flights to maintain order
            const container = document.getElementById('flight-list');
            flights.forEach(flight => container.appendChild(flight));
        }
    </script>
</div>
<?php /**PATH C:\Users\user\p\silex\mymore\mymore-w\resources\views\livewire\page\flight-result.blade.php ENDPATH**/ ?>