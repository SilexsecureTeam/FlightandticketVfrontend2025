<div x-data="{ 
    timer: 300,
    formatTime() {
        const minutes = Math.floor(this.timer / 60);
        const seconds = this.timer % 60;
        return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }
}" x-init="
    setInterval(() => {
        if (timer > 0) {
            timer--;
        } else {
            window.location.href = '/booking';
        }
    }, 1000);
">
    <!-- Timer Component -->
    <div class="bg-gradient-to-r from-red-600 to-red-800 text-white py-3 px-4   z-50 shadow-lg">
        <div class="max-w-7xl mx-auto flex items-center justify-between">
            <div class="flex items-center space-x-3">
                <svg class="w-6 h-6 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span class="font-semibold text-lg">Session expires in</span>
            </div>
            <div class="text-3xl font-bold" x-text="formatTime()"></div>
        </div>
    </div>

    <div 
    x-data="{ 
      currentStep: 'payment',
      steps: [
        {id: 'search-flight', label: 'Search Flight'},
        {id: 'select-flight', label: 'Select Flight'},
        {id: 'additional-info', label: 'Additional Info'},
        {id: 'payment', label: 'Payment'}
      ]
    }"
    class="bg-black sticky top-[14%] w-full z-[99]"
    >
    <div class="px-5 sm:px-5 md:px-16 py-4">
      <div class="flex items-center justify-between space-x-4 mb-2">
        <!-- Title -->
        <div class="text-lg font-bold text-white shrink-0">Flight Details</div>
        
        <!-- Stepper container -->
        <div class="flex-1 hidden md:block relative min-h-[64px] max-w-3xl mx-auto">
          <div class="absolute inset-0 flex items-center justify-between px-4">
            <!-- Progress bar background -->
            <div class="absolute h-1 bg-gray-700 w-full"></div>
            
            <!-- Active progress bar -->
            <div 
              class="absolute h-1 bg-primary transition-all duration-300"
              :style="'width: ' + (steps.findIndex(step => step.id === currentStep) / (steps.length - 1) * 100) + '%'"
            ></div>
            
            <!-- Steps container -->
            <div class="relative flex justify-between w-full">
              <template x-for="(step, index) in steps" :key="step.id">
                <div class="relative flex flex-col items-center w-24">
                  <!-- Circle -->
                  <div 
                    class="w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 z-10"
                    :class="{
                      'bg-primary text-white': currentStep === step.id,
                      'bg-white text-black': steps.findIndex(s => s.id === currentStep) > index,
                      'bg-white text-gray-400': steps.findIndex(s => s.id === currentStep) < index
                    }"
                  >
                    <span x-text="index + 1" class="text-sm font-medium"></span>
                  </div>
                  <!-- Label -->
                  <div 
                    class="absolute -bottom-6 text-xs text-center w-full transition-all duration-300"
                    :class="{
                      'text-primary': currentStep === step.id,
                      'text-white': steps.findIndex(s => s.id === currentStep) > index,
                      'text-white': steps.findIndex(s => s.id === currentStep) < index
                    }"
                  >
                    <span x-text="step.label" class="inline-block"></span>
                  </div>
                </div>
              </template>
            </div>
          </div>
        </div>
        
        <!-- Back button -->
        <a href="/booking" class="text-sm bg-white px-4 py-2 rounded-xl text-black shrink-0">Back</a>
      </div>
    </div>
    </div>

   

  
    <main class="nanum-gothic-regular block md:flex justify-around px-2  md:pt-20 py-20 bg-gray-100">
      <!-- Payment Methods -->
      <div class="md:w-[50%] w-full">
          <!-- Note Section -->
          <div class="px-8 py-8 bg-gradient-to-br from-white to-red-50 shadow-2xl rounded-3xl mb-8 border border-red-100 transition-all duration-300 hover:shadow-red-100">
              <h3 class="text-2xl font-bold text-primary mb-6 flex items-center">
                  <svg class="w-8 h-8 mr-3 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Important Note
              </h3>
              <ul class="list-none space-y-6 text-gray-700">
                  <li class="flex items-start p-4 bg-white rounded-xl shadow-md transition-all duration-300 hover:shadow-lg hover:scale-105">
                      <svg class="w-6 h-6 mr-3 text-red-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <div>
                          <strong class="text-primary block mb-1">Select Payment Method:</strong>
                          <span class="text-gray-600">Choose your preferred payment method by clicking the respective tab (Paystack or Alat Pay).</span>
                      </div>
                  </li>
                  <li class="flex items-start p-4 bg-white rounded-xl shadow-md transition-all duration-300 hover:shadow-lg hover:scale-105">
                      <svg class="w-6 h-6 mr-3 text-red-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <div>
                          <strong class="text-primary block mb-1">For Alat Pay:</strong>
                          <span class="text-gray-600">Verify your payment details and click the "Pay Now" button to complete the transaction securely.</span>
                      </div>
                  </li>
                  <li class="flex items-start p-4 bg-white rounded-xl shadow-md transition-all duration-300 hover:shadow-lg hover:scale-105">
                      <svg class="w-6 h-6 mr-3 text-red-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <div>
                          <strong class="text-primary block mb-1">Need Assistance?</strong>
                          <span class="text-gray-600">Contact our support team if you encounter any issues during the payment process.</span>
                          <a href="#" class="block mt-2 text-red-600 hover:underline">Get Help</a>
                      </div>
                  </li>
              </ul>
          </div>


          <div class="bg-white hidden md:block  rounded-3xl shadow-xl p-8 border border-gray-200/50 mt-5 space-y-8">
              <div class="flex items-center justify-between">
                <h2 class="text-2xl font-bold text-gray-800">Price Summary</h2>
                <div class="p-2 rounded-full bg-red-100 text-red-600">
                  <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" stroke-width="2" stroke-linecap="round"/>
                  </svg>
                </div>
              </div>
              
              <div class="space-y-4">
                <div class="flex justify-between items-center text-gray-600 bg-gray-50 p-4 rounded-lg">
                  <span class="font-medium">Currency</span>
                  <span class="font-bold text-gray-800"><?php echo e($price['currency'] ?? 'NGN'); ?></span>
                </div>
                <div class="flex justify-between items-center text-gray-600 bg-gray-50 p-4 rounded-lg">
                  <span class="font-medium">Base Fee</span>
                  <span class="font-bold text-gray-800"><?php echo e($price['currency'] ?? "NGN"); ?> <?php echo e(number_format($price['base'] ?? '')); ?></span>
                </div>
                <div class="flex justify-between items-center text-gray-600 bg-gray-50 p-4 rounded-lg">
                  <span class="font-medium">Taxes & Fees</span>
                  <span class="font-bold text-gray-800"><?php echo e($price['currency'] ?? 'NGN'); ?> 00.00</span>
                </div>
                <div class="flex justify-between items-center pt-4 border-t border-gray-200 text-xl font-bold text-gray-800">
                  <span>Total Amount</span>
                  <span class="text-red-600"> <?php echo e($price['currency']?? 'NGN'); ?> <?php echo e(number_format($price['grandTotal'] + $markUp ?? '')); ?></span>
                </div>
              </div>
    
              <div class="space-y-6">
                <div class="bg-red-50 border border-red-200 p-4 rounded-xl">
                  <p class="text-primary text-sm flex items-start gap-3">
                    <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                    <span>Book now! Price can change if you come back later.</span>
                  </p>
                </div>
    
                <p class="text-center text-sm text-gray-500">
                  By clicking continue, you agree to our
                  <a href="#" class="text-red-600 hover:underline">Terms</a>
                  and
                  <a href="#" class="text-red-600 hover:underline">Privacy Policy</a>
                </p>
              </div>
            </div>
          

         
      </div>

      <!-- Summary Section -->
      <div class="md:w-[40%] font-sans">
          <!-- Reserve and Pay Later Section -->
          <div x-data="{ showModal: false }" class="mb-8">
              <!-- Reserve and Pay Later Button -->
              <button 
                  @click="showModal = true" 
                  class="w-full py-3 px-4 bg-primary text-white font-semibold rounded-lg hover:bg-black focus:outline-none focus:ring-2 focus:ring-offset-2 transition duration-300 shadow-md flex items-center justify-center text-lg"
              >
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  Reserve and Pay Later
              </button>
          
              <!-- Modal Overlay -->
              <div 
              x-cloak
                  x-show="showModal"
                  x-transition:enter="ease-out duration-300"
                  x-transition:enter-start="opacity-0"
                  x-transition:enter-end="opacity-100"
                  x-transition:leave="ease-in duration-200"
                  x-transition:leave-start="opacity-100"
                  x-transition:leave-end="opacity-0"
                  class="fixed inset-0 z-50 flex items-center z-[9999999] justify-center bg-black bg-opacity-70"
                  @click.away="showModal = false"
              >
                  <!-- Modal Content -->
                  <div 
                      class="bg-white w-11/12 sm:w-3/4 md:w-1/2 p-8 rounded-2xl shadow-2xl relative transform transition-all"
                      @click.stop
                  >
                      <h3 class="text-2xl font-bold mb-4 text-gray-800">Reserve and Pay Later</h3>
                      <div class="h-1 w-20 bg-blue-500 mb-6 rounded-full"></div>
                      <p class="text-gray-700 mb-4 text-lg">
                          By selecting this option, you agree to complete the payment within 24 hours. 
                          Failure to pay within the specified timeframe may result in the cancellation of your reservation.
                      </p>
                      <div class="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6 rounded-r">
                          <p class="text-blue-700">
                              Please note that prices are subject to change after the reservation period.
                          </p>
                      </div>
          
                      <!-- Action Buttons -->
                      <div class="flex justify-end space-x-4">
                          <button 
                              @click="showModal = false" 
                              class="py-3 px-6 bg-gray-200 text-gray-800 font-medium rounded-lg hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-300 transition duration-300"
                          >
                              Cancel
                          </button>
                          <button 
                          type="button"
                          wire:click='offlineBooking'
                          wire:target='offlineBooking'
                          class="py-3 px-6 bg-primary text-white font-medium rounded-lg focus:outline-none focus:ring-2 focus:ring-offset-2 transition duration-300 shadow-md"
                      >
                        <div wire:loading.remove    wire:target="offlineBooking">
                          Confirm Reservation
                          </div>  

                          <div wire:loading     wire:target="offlineBooking"
class="w-10 h-10 border-4 border-t-primary border-gray-300 rounded-full animate-spin"
></div>
                      </button>
                      
                      </div>
                  </div>
              </div>
          </div>
      
       
              <div class="lg:sticky lg:top-32 h-fit">
               <!-- Tab Buttons -->
               <div class="flex gap-4 ">
                  <button 
                      class="w-1/2 py-4 text-center shadow-xl rounded-2xl font-semibold text-lg transition duration-300 ease-in-out <?php echo e($selectedPayment === 'Alat Pay' ? 'bg-primary text-white' : 'bg-white text-red-600 hover:bg-red-50'); ?>" 
                      wire:click="updatePaymentMethod('Alat Pay')">
                      Alat Pay
                  </button>
                  <button 
                      class="w-1/2 py-4 text-center shadow-xl rounded-2xl font-semibold text-lg transition duration-300 ease-in-out <?php echo e($selectedPayment === 'Paystack' ? 'bg-primary text-white' : 'bg-white text-red-600 hover:bg-red-50'); ?>" 
                      wire:click="updatePaymentMethod('Paystack')">
                      Paystack
                    
                  </button>
              </div>
  
              <!-- Dynamic Payment Section -->
              <?php if($selectedPayment === 'Alat Pay'): ?>
              <div class="py-8 p-5 mt-8 bg-white rounded-3xl shadow-xl">
                  <img src="https://alatpay.ng/static/media/logo.8bdf3d450f27d18190ab.png" alt="Paystack logo" class="size-12 mb-6 mx-auto">
                  <div class="flex flex-col gap-4 mt-8 md:w-[80%] mx-auto">
                      <div class="flex justify-between items-center bg-gray-50 p-4 rounded-lg">
                          <h6 class="text-gray-700 font-medium md:text-lg text-base">Base Price</h6>
                          <h6 class="text-gray-900 font-bold md:text-xl text-base"><?php echo e($price['currency']?? 'NGN'); ?> <?php echo e(number_format($price['base'] ?? '')); ?></h6>
                      </div>
                      <div class="flex justify-between items-center bg-gray-50 p-4 rounded-lg">
                          <h6 class="text-gray-700 font-medium md:text-lg text-base">Transaction Charge</h6>
                          <h6 class="text-gray-900 font-bold md:text-xl text-base"><?php echo e($price['currency']?? 'NGN'); ?> 0.00</h6>
                      </div>
                      <div class="flex justify-between items-center bg-red-50 p-4 rounded-lg mt-4">
                          <h6 class="text-primary font-semibold md:text-xl text-base">Grand Total:</h6>
                          <h6 class="text-primary font-bold md:text-lg text-base"><?php echo e($price['currency']?? 'NGN'); ?> <?php echo e(number_format($price['grandTotal'] + $markUp ?? '')); ?></h6>
                      </div>
                      <button 
                          class="w-full font-bold md:text-xl text-base px-6 py-4 mt-8 rounded-xl text-white bg-primary  transition duration-300 ease-in-out shadow-lg flex justify-center items-center"
                         onclick="showPayment()"
                          <?php echo e($isLoading ? 'disabled' : ''); ?>>
                          <?php if($isLoading): ?>
                              <div class="w-6 h-6 border-4 border-t-4 border-white rounded-full spinner-border animate-spin mr-3"></div>
                              Processing...
                          <?php else: ?>
                              Pay <?php echo e($price['currency']?? 'NGN'); ?> <?php echo e(number_format($price['grandTotal'] + $markUp ?? '')); ?> Now
                          <?php endif; ?>
                      </button>
                  </div>
              </div>
         
              <?php elseif($selectedPayment === 'Paystack'): ?>
              <div class="py-8 p-5 mt-8 bg-white rounded-3xl shadow-xl">
                  <img src="https://website-v3-assets.s3.amazonaws.com/assets/img/hero/Paystack-mark-white-twitter.png" alt="Paystack logo" class="w-24 h-24 mb-6 mx-auto">
                  <div class="flex flex-col gap-4 mt-8 md:w-[80%] mx-auto">
                      <div class="flex justify-between items-center bg-gray-50 p-4 rounded-lg">
                          <h6 class="text-gray-700 font-medium md:text-lg text-base">Base Price</h6>
                          <h6 class="text-gray-900 font-bold md:text-xl text-base"><?php echo e($price['currency']?? 'NGN'); ?> <?php echo e(number_format($price['base'] ?? '')); ?></h6>
                      </div>
                      <div class="flex justify-between items-center bg-gray-50 p-4 rounded-lg">
                          <h6 class="text-gray-700 font-medium md:text-lg text-base">Transaction Charge</h6>
                          <h6 class="text-gray-900 font-bold md:text-xl text-base"><?php echo e($price['currency']?? 'NGN'); ?> 0.00</h6>
                      </div>
                      <div class="flex justify-between items-center bg-red-50 p-4 rounded-lg mt-4">
                          <h6 class="text-primary font-semibold md:text-xl text-base">Grand Total:</h6>
                          <h6 class="text-primary font-bold md:text-2xl text-base"><?php echo e($price['currency']?? 'NGN'); ?> <?php echo e(number_format($price['grandTotal'] + $markUp ?? '')); ?></h6>
                      </div>
                      <button 
                          class="w-full font-bold md:text-xl text-base px-6 py-4 mt-8 rounded-xl text-white bg-primary  transition duration-300 ease-in-out shadow-lg flex justify-center items-center"
                          wire:click="processPayment" 
                          <?php echo e($isLoading ? 'disabled' : ''); ?>>
                          <?php if($isLoading): ?>
                              <div class="w-6 h-6 border-4 border-t-4 border-white rounded-full spinner-border animate-spin mr-3"></div>
                              Processing...
                          <?php else: ?>
                              Pay <?php echo e($price['currency']?? 'NGN'); ?> <?php echo e(number_format($price['grandTotal'] + $markUp ?? '')); ?> Now
                          <?php endif; ?>
                      </button>
                  </div>
              </div>
              <?php endif; ?>
     
        
      </div>
  </main>



<!-- AlatPay Script -->
<script src="https://web.alatpay.ng/js/alatpay.js"></script>
<script>
    console.log("Last Name:", "<?php echo e($lastName); ?>");
  console.log("Currency:", "<?php echo e($currency); ?>");
  console.log("Amount:", <?php echo e($totalamount); ?>); 
  console.log("Email:", "<?php echo e($email); ?>");
  console.log("Phone:", "<?php echo e($phone); ?>");

  // Initialize AlatPay with dynamic data
  let popup = Alatpay.setup({
      apiKey: "3e0c19b031fe4e5bb9b51a200cb86440", // Replace with your AlatPay API key
      businessId: "99fe948e-bafe-4bd3-92be-08dcabf3e16e", // Replace with your AlatPay Business ID
      email: "<?php echo e($email); ?>", // Customer email
      phone: "<?php echo e($phone); ?>", // Customer phone number
      firstName: "<?php echo e($firstName); ?>", // Customer first name
      lastName: "<?php echo e($lastName); ?>", // Customer last name
      metaData: null, // Optional metadata
      currency: "<?php echo e($currency); ?>", // Currency (e.g., NGN)
      amount: 100, // Payment amount
      onTransaction: function(response) {
          console.log("API response is ", response);
          // Handle transaction success or failure here
          window.location.href = '/payment/success'; // Redirect to success page
      },
      onClose: function() {
          console.log("Payment gateway is closed");
      }
  });

  // Function to show the AlatPay payment modal
  function showPayment() {
      popup.show();
  }
</script>
</div><?php /**PATH C:\Users\user\p\silex\mymore\mymore-w\resources\views\livewire\booking\payment-booking.blade.php ENDPATH**/ ?>